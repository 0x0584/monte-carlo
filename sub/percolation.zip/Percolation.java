import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation
{
	private static final String ExcpNegative = "n is not valid! must be > 0";
	private static final String ExcpBounds = "site out of bound!";

	private final int TOP;
	private	final int BOTTOM;
	private final int SIZE;

	private final WeightedQuickUnionUF uf;
	private boolean[] open_sites;
	private int n_open;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n)
	{
		if (n <= 0)
			throw new IllegalArgumentException(ExcpNegative);

		uf = new WeightedQuickUnionUF(n * n);

		n_open = 0;
		open_sites = new boolean[n * n];

		SIZE = n;
		TOP = SIZE;
		BOTTOM = 1;
	}

	private int site(int row, int col)
	{
		if (row < BOTTOM || TOP < row
				|| col < BOTTOM || TOP < col)
			throw new IllegalArgumentException(ExcpBounds);
		row--;
		col--;
		return row * SIZE + col;
	}

	// opens the site (row, col) if it is not open already
	public void open(int row, int col)
	{
		final int[] dx = {0, 0, 1, -1};
		final int[] dy = {1, -1, 0, 0};

		if (isOpen(row, col))
			return;

		n_open += 1;
		open_sites[site(row, col)] = true;
		for (int i = 0; i < 4; ++i) {
			int x = col + dx[i];
			int y = row + dy[i];
			try {
				int neighbor = site(y, x);
				if (open_sites[neighbor])
					uf.union(site(row, col), neighbor);
			} catch(IllegalArgumentException e) {
				continue;
			}
		}
	}

    // is the site (row, col) open?
    public boolean isOpen(int row, int col)
	{
		return open_sites[site(row, col)];
	}

	// is the site (row, col) full?
	public boolean isFull(int row, int col)
	{
		if (!isOpen(row, col))
			return false;

		int canonical = uf.find(site(row, col));
		for (int bottom = 1; bottom <= SIZE; ++bottom)
			if (canonical == uf.find(site(BOTTOM, bottom)))
				return true;

		return false;
	}

	// returns the number of open sites
	public int numberOfOpenSites()
	{
		return n_open;
	}

	// does the system percolate?
	public boolean percolates()
	{
		for (int col = 1; col <= SIZE; ++col)
			if (isFull(TOP, col))
				return true;
		return false;
	}

	// test client (optional)
	public static void main(String[] args)
		throws IllegalArgumentException
	{
		int n = StdIn.readInt();
		Percolation perc = new Percolation(n);

		while (!StdIn.isEmpty())
			perc.open(StdIn.readInt(),
					  StdIn.readInt());

		StdOut.println("percolates? " + perc.percolates());
		StdOut.println("open_sites? " + perc.numberOfOpenSites());

		while (!perc.percolates())
			perc.open(StdRandom.uniform(1, n + 1),
					  StdRandom.uniform(1, n + 1));

		StdOut.println("percolates? " + perc.percolates());
		StdOut.println("open_sites? " + perc.numberOfOpenSites());
	}
}
